
#include "gtest/gtest.h"
#include "SetCommand.h"
#include <fstream>

class testSetCommand: public ::testing::Test, public SetCommand
{
public:
	testSetCommand(){};

};


TEST_F(testSetCommand, SetCommandArguments)
{

	Result result=ReadArguments("");//not enough arguments
	ASSERT_FALSE(result.status);
	result=ReadArguments("correct");//not enough arguments
	ASSERT_FALSE(result.status);
	result=ReadArguments("correct correct");
	ASSERT_TRUE(result.status);
	result=ReadArguments("correct correct fault");//too many arguments
	ASSERT_FALSE(result.status);
	result=ReadArguments("correct correct fault efefewfwf wjfdvewjfvew");//too many arguments
	ASSERT_FALSE(result.status);
	result=ReadArguments("correct correct fault efefewfwf wjfdvewjfvew");//too many arguments
	ASSERT_FALSE(result.status);

}


