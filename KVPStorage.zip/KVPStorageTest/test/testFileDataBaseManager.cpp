/*
 * testFileDataBaseManager.cpp
 *
 *  Created on: Sep 10, 2020
 *      Author: wissem
 */
#include "gtest/gtest.h"
#include "FileDataBaseManager.h"
#include <fstream>



const std::string settingsTestOnlyFile="settingsTestOnlyFile";

class testFileDataBaseManager: public ::testing::Test
{
public:
	testFileDataBaseManager();
	FileDataBaseManager testFileManager;

};

testFileDataBaseManager::testFileDataBaseManager(): testFileManager(settingsTestOnlyFile)
{

}

TEST_F(testFileDataBaseManager, SetGetCommandTest)
{
	DataBaseManagerIface* iface=&testFileManager;
	ASSERT_STREQ(iface->SetSetting("test", "1").result.c_str(),"OK");
	ASSERT_STREQ(iface->SetSetting("test", "1").result.c_str(),"OK");//for the same key-->same value
	ASSERT_STREQ(iface->GetSetting("test").result.c_str(),"1");
	ASSERT_STREQ(iface->SetSetting("longword", "lonnnnnnnnnnnnnnnnnnnnnnnngggggggggggggggggg").result.c_str(),"OK");
	ASSERT_STREQ(iface->GetSetting("longword").result.c_str(),"lonnnnnnnnnnnnnnnnnnnnnnnngggggggggggggggggg");//long value
	ASSERT_STREQ(iface->SetSetting("", "dfdfd").result.c_str(),"Error, key can not be empty!\n");//empty key
	ASSERT_STREQ(iface->SetSetting("longggggggggggggggggggggggggggggggggggggggggggggggg", "loooooooooooooooooongggggggggggggggggggggggggggggggggggg").result.c_str(),"OK");//long key+value
	ASSERT_STREQ(iface->GetSetting("longggggggggggggggggggggggggggggggggggggggggggggggg").result.c_str(),"loooooooooooooooooongggggggggggggggggggggggggggggggggggg");

}

TEST_F(testFileDataBaseManager, DeleteCommandTest)
{
	DataBaseManagerIface* iface=&testFileManager;
	ASSERT_STREQ(iface->SetSetting("test", "1").result.c_str(),"OK");
	ASSERT_STREQ(iface->DeleteSetting("test").result.c_str(),"OK");
	ASSERT_TRUE(iface->GetSetting("test").result.empty());
	ASSERT_STREQ(iface->DeleteSetting("test").result.c_str()," setting : test does not exist! \n");//setting has already been deleted

}

TEST_F(testFileDataBaseManager, SeSetGetDeleteCommandsAllCombined)
{
	DataBaseManagerIface* iface=&testFileManager;
	ASSERT_STREQ(iface->SetSetting("test", "1").result.c_str(),"OK");
	ASSERT_STREQ(iface->SetSetting("test", "1").result.c_str(),"OK");//for the same key-->same value
	ASSERT_STREQ(iface->GetSetting("test").result.c_str(),"1");
	ASSERT_STREQ(iface->DeleteSetting("test").result.c_str(),"OK");
	ASSERT_STREQ(iface->DeleteSetting("test").result.c_str()," setting : test does not exist! \n");
	ASSERT_TRUE(iface->GetSetting("test").result.empty());
	ASSERT_STREQ(iface->SetSetting("wissem", "hello").result.c_str(),"OK");
	ASSERT_STREQ(iface->GetSetting("wissem").result.c_str(),"hello");

}


