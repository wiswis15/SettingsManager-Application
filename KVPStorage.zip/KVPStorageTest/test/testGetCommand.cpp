
#include "gtest/gtest.h"
#include "GetCommand.h"


class testGetCommand: public ::testing::Test, public GetCommand
{
public:
	testGetCommand(){};

};


TEST_F(testGetCommand, GetCommandArguments)
{

	Result result=ReadArguments("");// empty argument!
	ASSERT_FALSE(result.status);
	ASSERT_STREQ(result.result.c_str(),"Error: argument can not be empty \n");
	result=ReadArguments("test");//ok
	ASSERT_TRUE(result.status);
	result=ReadArguments("tes2323t test12131");//too many
	ASSERT_FALSE(result.status);
	result=ReadArguments("correct correct fault");//too many arguments
	ASSERT_FALSE(result.status);
	result=ReadArguments("correct correct 233 efefewfwf wjfdvewjfvew");//too many arguments
	ASSERT_FALSE(result.status);
	result=ReadArguments("correct correct 3233'' efefewfwf wjfdvewjfvew");//too many arguments
	ASSERT_FALSE(result.status);

}


